const mongoose = require("mongoose");
//Write missing code here
mongoose
  .connect(
   'mongodb+srv://albinsunil:ZV1QhGR9PE8Tr92W@cluster0.9uazear.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
  )
  .then(() => {
    console.log("Connected to DB");
  })
  .catch((error) => {
    console.log(error);
  });